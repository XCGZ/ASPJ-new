x = ["The don't laugh challenge", 'How to draw everything for kids', 'Book on Planet Earth', 'Kids Encyclopedia', 'I am 10 and amazing', 'Ocean Animals', 'Inspiring Stories for Kids']

# x.sort()
# count = 0
# for i in x:
#     count += 1
#     if count == 3:

#         print(i, end='\n')
#         count = 0
#         print('')
#     else:
#         print(i, end='            ')

str_1 = '''
hello dog
hi'''

print(str_1)