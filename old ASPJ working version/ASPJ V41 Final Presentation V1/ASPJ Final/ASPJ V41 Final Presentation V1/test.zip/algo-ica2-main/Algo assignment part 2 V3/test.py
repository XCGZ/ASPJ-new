import Book
import populateData
from stock_stack import StockStack, RestockDetail
stack = StockStack()
book_list = []
records = 1



def book_management():
    global book_list
    global records
    while True:
        print('BOOK MANAGEMENT SYSTEM')
        print('1. Add new Books.')
        print('2. Display All Books.')
        print('3. Sort members by Category using only Bubble Sort in ascending order.')
        print('4. Sort members by Publisher using selection sort in descending order.')
        print('5. Sort books via Insertion sort on Book Title (ascending).')
        print('6. Sort books via Merge sort on Category (descending) follow by quantity(ascending)')
        print('7. Go to Restocking Menu')
        print('8  Set number of records per row to display')
        print('9. Populate Data.')
        print('0. Exit Program.')
        user_input = int(input('Please Select: '))

        if user_input == 0:
            print('Good Bye!')
            break
            
        elif user_input == 1:
            book_list.append(add_new_books())
            print('New Book added successfully!')
            
        elif user_input == 2:
            if book_list == []:
                print(' ')
            else:
                if records != 0:
                    display_all_books(records)
                else:
                    print('Please enter number of records per row to display')
            

        elif user_input == 3:
            if book_list != []:
                if records != 0:
                    book_list = sort_ascending(book_list)
                    display_records_function(book_list,0, records)
                else:
                    print('Please enter number of records per row to display')
            

                
                
        elif user_input == 4:
            if book_list != []:
                if records != 0:
                    book_list = sort_descending(book_list)
                    display_records_function(book_list,0, records)
                else:
                    print('Please enter number of records per row to display')
        
        elif user_input == 5:
            if book_list != []:
                if records != 0:
                    book_list = insertion_sort(book_list)
                    display_records_function(book_list,0, records)
                else:
                    print('Please enter number of records per row to display')


        elif user_input == 6:
            if book_list != []:
                if records != 0:
                    book_list = merge_sort_category(book_list)
                    book_list = merge_sort_quantity(book_list)
                    display_records_function(book_list,0, records)
                else:
                    print('Please enter number of records per row to display')
        
        elif user_input == 7:
            restock_menu()
        
        elif user_input == 8:
            records = select_rows()

        elif user_input == 9:
            book_list = populateData.populateData()

        else:
            print('Please Try Again')

def add_new_books():
    enter_ISBN = input('Enter Book ISBN Number::')
    enter_title = input('Enter Book Title:')
    enter_category = input('Enter Book Category:')
    enter_publisher = input('Enter publisher:')
    enter_year_published = input('Enter year published:')
    enter_qty = input('Enter qty:')
    NewBook = Book.Book(enter_ISBN, enter_title, enter_category, enter_publisher, enter_year_published, enter_qty)
    return NewBook

def display_records_function(book_list,index, records_row):
    print()
    if index >= len(book_list):
        return
    end_index = min(index + records_row, len(book_list))

    for i in range(index, end_index):
        ISBN = book_list[i].get_ISBN()
        print(f"Book ISBN Number: {ISBN}", end='\t\t\t\t')
    print('', end='\n')

    for i in range(index, end_index):
        Title = book_list[i].get_Title()
        padding = 41 - len(Title)
        print(f"Title: {Title}",  end=' ' * padding)
    print('', end='\n')

    for i in range(index, end_index):
        Category = book_list[i].get_Category()
        print(f"Category: {Category}", end='\t\t\t\t')
    print('', end='\n')

    for i in range(index, end_index):
        Publisher = book_list[i].get_Publisher()
        print(f"Publisher: {Publisher}", end='\t\t\t\t')

    print('', end='\n')

    for i in range(index, end_index):
        Year_Published = book_list[i].get_Year_Published()
        print(f"Year_Published: {Year_Published}", end='\t\t\t\t')
    print('', end='\n')

    for i in range(index, end_index):
        qty = book_list[i].get_qty()
        print(f"Quantity: {qty}", end='\t\t\t\t\t')
    print('', end='\n')

    index = end_index
    
    print()
    display_records_function(book_list,index, records_row)

def display_all_books(records_row):
    display_records_function(book_list,0, records_row)




def sort_ascending(book_list):
    # alphabet_list = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
    n = len( book_list )
    for i in range( n - 1, 0, -1):
        print(f'Pass: {n-i}')
        print('-----------------------------')
        for j in range(i):  
            # if alphabet_list.index(book_list[j].Category[0]) > alphabet_list.index(book_list[j + 1].Category[0]):
            if book_list[j].get_Category() > book_list[j+1].get_Category():
                tmp = book_list[j]
                book_list[j] = book_list[j + 1]
                book_list[j + 1] = tmp

        for book in book_list:
            print(f'ISBN Number: {book.get_ISBN()}')
    print(' ')
    print('-----------------------------')
    return book_list

def sort_descending( book_list ):
    n = len(book_list)
    for i in range(n - 1):
        # assume this biggest_num index represents the biggest num in the list.
        biggest_num = i
        print(f'Pass: {i + 1}')
        print('-----------------------------')

        for j in range(i + 1, n):
            # check if value of num that is one more index than biggest num is bigger than the value of biggest num.
            # sorted by length of publisher.
            if book_list[j].get_Publisher() > book_list[biggest_num].get_Publisher():
                biggest_num = j

        if biggest_num != i:
            tmp = book_list[i]
            book_list[i] = book_list[biggest_num]
            book_list[biggest_num] = tmp
        
        for book in book_list:
            print(f'ISBN Number: {book.get_ISBN()}')
    print(' ')
    print('-----------------------------')
    return book_list

def insertion_sort(book_list):
    n = len(book_list)
    for i in range(1, n):
        Title = book_list[i].get_Title()
        value = book_list[i]
        print(f'Pass {i}' )
        print('-----------------------------')

        pos = i
        while pos > 0 and Title < book_list[pos-1].get_Title():
            book_list[pos] = book_list[pos-1]
            pos -= 1
        
        book_list[pos] = value
        for book in book_list:
            print(book.get_ISBN())
        print('-----------------------------')
    
            
    return book_list

def merge_sort_category(book_list):
    if len(book_list) <= 1:
        return book_list
    else:
        mid = len(book_list) // 2
        leftHalf = merge_sort_category( book_list[:mid])
        rightHalf = merge_sort_category(book_list[mid:])

        newlist = mergeSortedLists(leftHalf, rightHalf)
        print('New List: ')
        print('-----------------------------')
        for book in newlist:
            print(book.get_ISBN())
        print('-----------------------------')
        return newlist


def mergeSortedLists(listA, listB):
    newList = list()
    a = 0
    b = 0
        # Merge the two lists together until one is empty
    while a < len( listA ) and b < len( listB ):
        if listA[a].get_Category() >= listB[b].get_Category():
            newList.append( listA[a] )
            a += 1
        else:
            newList.append( listB[b] )
            b += 1

    # If listA contains more items, append remaining items to newList
    while a < len( listA ):
        newList.append( listA[a] )
        a += 1

    # If listB contains more items, append remaining items to newList
    while b < len( listB ):
        newList.append( listB[b] )
        b += 1

    return newList

def merge_sort_quantity(book_list):
    if len(book_list) <= 1:
        return book_list
    else:
        mid = len(book_list) // 2
        leftHalf = merge_sort_quantity( book_list[:mid])
        rightHalf = merge_sort_quantity(book_list[mid:])

        newlist = mergeSortedQuantityLists(leftHalf, rightHalf)
        return newlist


def mergeSortedQuantityLists(listA, listB):
    newList = list()
    a = 0
    b = 0
        # Merge the two lists together until one is empty
    while a < len( listA ) and b < len( listB ):
        if listA[a].get_qty() <= listB[b].get_qty():
            newList.append( listA[a] )
            a += 1
        else:
            newList.append( listB[b] )
            b += 1

    # If listA contains more items, append remaining items to newList
    while a < len( listA ):
        newList.append( listA[a] )
        a += 1

    # If listB contains more items, append remaining items to newList
    while b < len( listB ):
        newList.append( listB[b] )
        b += 1

    return newList

def restock_menu():
    while True:
        print('Restocking Menu')
        print('1. Enter new stock arrival')
        print('2. View number of stock in stack')
        print('3. Service top of stack')
        print('0. Return to Main Menu')
        user_input = int(input('Please select one: '))
        if user_input == 1:
            add_stock_arrival(book_list)
        elif user_input == 2:
            view_stock()
        elif user_input == 3:
            service_stack(book_list)
        elif user_input == 0:
            return


def view_stock():
    print(f'Number of delivery in stack: {stack.__len__()}')
    return

def add_stock_arrival(book_list):
    x = False
    while x == False:
        user_input = input('Enter book ISBN: ')
        for book in book_list:
            if user_input == book.get_ISBN():
                quantity_input = int(input('Enter qty to restock: '))
                restock_details = RestockDetail(user_input,quantity_input)
                stack.push(restock_details)
                print("Delivery Arrival added successfully!")
                x = True
        if x == False:
            print("Book Not Found. Please try again.")
    return
    

def service_stack(book_list):
    if not stack.isEmpty():
        stack_top = stack.pop()
    else:
        print('Stack is empty')
    for book in book_list:
        if book.get_ISBN() == stack_top.get_ISBN():
            print(f'Display Pending stock arrival: ')
            print('-----------------------------')
            print(f'Book ISBN Number: {book.get_ISBN()}')
            print(f'Title: {book.get_Title()}')
            print(f'Category: {book.get_Category()}')
            print(f'Publisher: {book.get_Publisher()}')
            print(f'Year Published: {book.get_Year_Published()}')
            print(f'Quantity: {book.get_qty()}')
            print('-----------------------------')
            print(f'New Stock: {stack_top.get_qty()}')
            print('-----------------------------')
            print(f'Remaining restock in stack: {stack.__len__()}')
            user_input = input("Proceed with restocking (Y/N): ")
            if user_input.upper() == 'Y':
                book.set_qty(stack_top.get_qty() + book.get_qty())
                print(f"Book ISBN: {book.get_ISBN()} updated stock: {book.get_qty()}")
            else:
                stack.push(stack_top)
                print(f"Product {stack_top.get_ISBN()} returned to stack!")
    return


def select_rows():
    user_input = int(input('please enter a number: '))
    return user_input




    



book_management()



